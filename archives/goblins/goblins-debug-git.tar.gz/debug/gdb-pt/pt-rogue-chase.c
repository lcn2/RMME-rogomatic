set confirm off
set pagination off
set logging file gdbrogue.txt
set logging overwrite on
set logging on
set breakpoint pending on
set listsize 20
set directories /home/me/rogo/rogue
define my_prt_mlist
  set $current = mlist
    while ($current > 0)
  printf "curr %p  prev %p  next %p\n", $current, $current->l_prev, $current->l_next
  printf "  t_type %c\n", $current->t_type
  printf "  t_pos.y %d t_pos.x %d\n", $current->t_pos.y, $current->t_pos.x
  if ($current->t_dest > 0)
    printf "  t_dest->y %d t_dest->x %d\n", $current->t_dest->y, $current->t_dest->x
    end
  set $current = $current->l_next
  end
end
break chase.c:441
commands
my_prt_mlist
bt
cont
end
break chase.c:85 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:109 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:127 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:129 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:202 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:211 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:226 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:303 if (level == 8)
commands
my_prt_mlist
bt
cont
end
break chase.c:306 if (level == 8)
commands
my_prt_mlist
bt
cont
end
cont
