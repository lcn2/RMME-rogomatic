define mypp2
#set $topleftx = rooms[$arg0].r_pos.x
#set $toplefty = rooms[$arg0].r_pos.y
#set $maxx = rooms[$arg0].r_max.x + 4
#set $maxy = rooms[$arg0].r_max.y + 4
#printf "TLx %d TLy %d maxx %d maxy %d\n", $topleftx, $toplefty, $maxx, $maxy
#
#set $rows = 0
#while $rows < $maxy
#  set $tmpcol = $topleftx
#  set $cols = 0
#  printf "%02d", $rows
#  while $cols < $maxx
#    printf "%c", chat($rows, $tmpcol + $cols)
#    set $cols++
#  end
#  printf "\n"
#  set $rows++
#  end
#end

set $topleftx = 0
set $toplefty = 0
set $maxy = 23
set $maxx = 78

set $rows = 13
while $rows < $maxy
  set $cols = 0
  printf "%02d", $rows
  while $cols < $maxx
    printf "%c", chat($rows, $cols)
    set $cols++
  end
  printf "\n"
  set $rows++
  end

set $topleftx = 0
set $toplefty = 0
set $maxy = 23
set $maxx = 78

set $rows = 13
while $rows < $maxy
  set $cols = 0
  printf "%02d", $rows
  while $cols < $maxx
    printf "%c", flat($rows, $cols)
    set $cols++
  end
  printf "\n"
  set $rows++
  end
end
